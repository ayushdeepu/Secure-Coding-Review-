"""
REMEDIATED VERSION - fixes for findings F1-F6 from the security audit.
See ../reports/audit-report.md and ../README.md for details on each fix.
"""

from flask import Flask, request, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os

app = Flask(__name__)

DB_PATH = "users.db"
UPLOAD_DIR = os.path.abspath("uploads")
MAX_USERNAME_LEN = 50


def get_db():
    return sqlite3.connect(DB_PATH)


def init_db():
    conn = get_db()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, "
        "username TEXT UNIQUE, password TEXT)"
    )
    conn.commit()
    conn.close()


@app.route("/login", methods=["POST"])
def login():
    username = request.form.get('username', '')
    password = request.form.get('password', '')

    # F6 fix: basic input validation
    if not username or not password:
        return "Invalid input", 400

    conn = get_db()
    cur = conn.cursor()

    # F1 fix: parameterized query, no string concatenation
    cur.execute(
        "SELECT password FROM users WHERE username = ?",
        (username,)
    )
    row = cur.fetchone()
    conn.close()

    # F2 fix: compare against hashed password
    if row and check_password_hash(row[0], password):
        return "Welcome " + username
    return "Invalid credentials", 401


@app.route("/register", methods=["POST"])
def register():
    username = request.form.get('username', '')
    password = request.form.get('password', '')

    # F6 fix: validate length and presence
    if not username or not password or len(username) > MAX_USERNAME_LEN:
        return "Invalid input", 400

    # F2 fix: hash the password before storing
    hashed = generate_password_hash(password)

    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (username, hashed)
        )
        conn.commit()
    except sqlite3.IntegrityError:
        return "Username already exists", 409
    finally:
        conn.close()

    return "Registered successfully"


@app.route("/profile")
def profile():
    name = request.args.get("name", "")

    # F3 fix: render via Jinja2 template with auto-escaping enabled
    return render_template("profile.html", name=name)


@app.route("/download")
def download():
    raw_filename = request.args.get("file", "")

    # F4 fix: sanitize filename and confine to UPLOAD_DIR
    filename = secure_filename(raw_filename)
    if not filename:
        return "Invalid file", 400

    safe_path = os.path.join(UPLOAD_DIR, filename)

    if not os.path.abspath(safe_path).startswith(UPLOAD_DIR):
        return "Invalid file", 400

    if not os.path.exists(safe_path):
        return "File not found", 404

    with open(safe_path, "r") as f:
        return f.read()


if __name__ == "__main__":
    init_db()
    os.makedirs(UPLOAD_DIR, exist_ok=True)

    # F5 fix: debug mode controlled via environment variable, defaults to off
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(debug=debug_mode)
